const UI_ID = 'danmaku-clap-ui-v2';
const SELECTOR_CANDIDATES = [
  'yt-live-chat-renderer',
  'yt-live-chat-app',
  'yt-live-chat-frame',
  '#chat',
  'tp-yt-iron-pages#panel-pages'
];

/* ---------- UI 作成とハンドラ ---------- */
function createUI() {
  if (document.getElementById(UI_ID)) return document.getElementById(UI_ID);

  const container = document.createElement('div');
  container.id = UI_ID;
  container.style.padding = '8px';
  container.style.border = '1px solid #ccc';
  container.style.margin = '8px';
  container.style.backgroundColor = '#fff';
  container.style.zIndex = '99999';
  container.style.boxShadow = '0 2px 6px rgba(0,0,0,0.2)';
  container.innerHTML = `
    <div style="display:flex;gap:8px;align-items:center;">
      <input id="danmakuInput" type="text" placeholder="弾幕を入力" style="flex:1;padding:6px;" />
      <button id="danmakuSend">弾幕入力</button>
    </div>
    <div style="display:flex;gap:8px;align-items:center;margin-top:6px;">
      <input id="clapInput" type="text" placeholder="拍手を入力" value="👏👏👏👏👏" style="flex:1;padding:6px;" />
      <button id="clapSend">拍手入力</button>
    </div>
  `;
  attachUIHandlers(container);
  return container;
}

function attachUIHandlers(container) {
  container.querySelector('#danmakuSend').addEventListener('click', async () => {
    const t = container.querySelector('#danmakuInput').value.trim();
    if (t) await insertTextDeep(t);
  });
  container.querySelector('#clapSend').addEventListener('click', async () => {
    const t = container.querySelector('#clapInput').value.trim();
    if (t) await insertTextDeep(t);
  });
  container.querySelector('#danmakuInput').addEventListener('keydown', async (e) => {
    if (e.key === 'Enter') {
      const t = e.target.value.trim();
      if (t) await insertTextDeep(t);
    }
  });
  container.querySelector('#clapInput').addEventListener('keydown', async (e) => {
    if (e.key === 'Enter') {
      const t = e.target.value.trim();
      if (t) await insertTextDeep(t);
    }
  });
}

/* ---------- UI 挿入補助 ---------- */
function tryInsertIntoChat(container) {
  for (const sel of SELECTOR_CANDIDATES) {
    const el = document.querySelector(sel);
    if (el) {
      try { el.appendChild(container); console.log('UI inserted into', sel); return true; }
      catch (err) { console.warn('Append failed for', sel, err); }
    }
  }
  return false;
}

function insertFallback(container) {
  container.style.position = 'fixed';
  container.style.right = '12px';
  container.style.bottom = '12px';
  container.style.width = '320px';
  document.body.appendChild(container);
}

/* ---------- 深掘り探索ユーティリティ ---------- */

// 再帰的に root (Document, ShadowRoot, Element) を探索して selector 条件に当てはまる要素を列挙
function querySelectorAllDeep(selector, root = document) {
  const results = [];
  try { results.push(...Array.from(root.querySelectorAll(selector))); } catch (e) {}
  const walker = (node) => {
    try {
      const children = (node.children || []);
      for (let i = 0; i < children.length; i++) {
        const el = children[i];
        try {
          if (el.shadowRoot) {
            try { results.push(...Array.from(el.shadowRoot.querySelectorAll(selector))); } catch(e){}
            walker(el.shadowRoot);
          }
        } catch(e){}
        walker(el);
      }
    } catch(e){}
  };
  try { walker(root); } catch(e){}
  return results;
}

// 再帰的探索で最初に見つかった要素を返す（iframe 内も探索）
function findFirstDeep(selectors) {
  for (const sel of selectors) {
    if (!sel) continue;
    // 親ドキュメント検索
    try {
      const found = Array.from(document.querySelectorAll(sel)).filter(Boolean);
      if (found.length) return { el: found[0], context: document };
    } catch(e){}
    // Shadow DOM 深掘り（親）
    try {
      const foundShadow = querySelectorAllDeep(sel, document);
      if (foundShadow.length) return { el: foundShadow[0], context: document };
    } catch(e){}
    // iframe 内探索（同一オリジンのみ）
    const iframes = Array.from(document.getElementsByTagName('iframe'));
    for (const f of iframes) {
      try {
        const doc = f.contentDocument;
        if (!doc) continue;
        // 直接 doc 内で見つける
        try {
          const dFound = Array.from(doc.querySelectorAll(sel)).filter(Boolean);
          if (dFound.length) return { el: dFound[0], context: doc, frame: f };
        } catch(e){}
        // shadow deep inside iframe document
        try {
          const deepFound = querySelectorAllDeep(sel, doc);
          if (deepFound.length) return { el: deepFound[0], context: doc, frame: f };
        } catch(e){}
      } catch (e) {
        // cross-origin iframe はスキップ
      }
    }
  }
  return null;
}

/* ---------- 書き込み本体：iframe を優先し、shadowRoot 内も探索して編集ノードを見つけて書く ---------- */

async function insertTextDeep(text) {
  console.log('insertTextDeep called:', text);

  // 優先して探索するセレクタ群
  const selectors = [
    'yt-live-chat-text-input-field-renderer#input',
    'yt-live-chat-text-input-field-renderer',
    '[contenteditable="true"][role="textbox"]',
    '[contenteditable="true"]',
    'textarea',
    'input[type="text"]'
  ];

  // 1) 最初に iframe 内深掘りで取得を試みる
  const found = findFirstDeep(selectors);
  if (!found) {
    console.warn('No candidate found by deep search. Try popout chat if possible.');
    return false;
  }

  // 2) コンテキスト（doc）と要素を決定
  const doc = found.context || document;
  const frame = found.frame || null;
  const host = found.el;
  console.log('candidate found:', { tag: host && host.tagName, id: host && host.id, classes: host && host.className, inFrame: !!frame });

  // 3) host の内部から実際に編集できるノードを探す（shadowRoot 内も含める）
  let editable = null;

  // helper: 深掘りで editable を探す（host の内部に限定）
  function findEditableInside(root) {
    try {
      // direct candidates
      const direct = Array.from((root.querySelectorAll && root.querySelectorAll('[contenteditable="true"], textarea, input[type="text"]')) || []);
      if (direct.length) return direct[0];
    } catch(e){}
    // traverse including shadow roots
    const stack = [root];
    while (stack.length) {
      const node = stack.shift();
      try {
        // check node itself
        if (node && (node.isContentEditable || node.tagName === 'TEXTAREA' || node.tagName === 'INPUT' || ('value' in node))) return node;
      } catch(e){}
      try {
        const children = node.children || [];
        for (let i = 0; i < children.length; i++) {
          stack.push(children[i]);
          if (children[i].shadowRoot) stack.push(children[i].shadowRoot);
        }
      } catch(e){}
      try {
        if (node && node.shadowRoot) {
          const srChildren = node.shadowRoot.children || [];
          for (let j = 0; j < srChildren.length; j++) stack.push(srChildren[j]);
        }
      } catch(e){}
    }
    return null;
  }

  try {
    // 3a) host 内部探索
    try { editable = findEditableInside(host); } catch(e){}
    // 3b) host 自体が editable か
    if (!editable) try { if (host && (host.isContentEditable || 'value' in host || host.tagName === 'TEXTAREA' || host.tagName === 'INPUT')) editable = host; } catch(e){}
    // 3c) context 全体を探索（iframe.document または parent document）
    if (!editable) try { editable = findEditableInside(doc.documentElement || doc); } catch(e){}
  } catch(e) {
    console.warn('Error during editable search', e && e.message);
  }

  if (!editable) {
    console.warn('No editable node located after deep search. Consider using chat popout.');
    return false;
  }

  // 4) 書き込み（doc の API を使う）、イベント発火、selection 設定
  try {
    // focus iframe window first if present
    try { if (frame && frame.contentWindow) frame.contentWindow.focus(); } catch(e){}

    try { editable.focus && editable.focus(); } catch(e){}

    // set value or text node inside the correct document (doc)
    if ('value' in editable) {
      editable.value = text;
    } else {
      // remove children then append text node using doc.createTextNode if possible
      try {
        while (editable.firstChild) editable.removeChild(editable.firstChild);
        const txt = (doc && doc.createTextNode) ? doc.createTextNode(text) : document.createTextNode(text);
        editable.appendChild(txt);
      } catch(e){
        try { editable.textContent = text; } catch(e){}
      }
    }

    // dispatch input-related events safely
    const safeDispatch = (node, type, opts = {}) => {
      try { node.dispatchEvent(new InputEvent(type, Object.assign({ bubbles:true, cancelable:true, composed:true }, opts))); }
      catch (e) {
        try { node.dispatchEvent(new Event(type, Object.assign({ bubbles:true, cancelable:true, composed:true }, {}))); }
        catch(e){}
      }
    };
    safeDispatch(editable, 'beforeinput', { inputType:'insertText', data:text });
    safeDispatch(editable, 'input', { inputType:'insertText', data:text });
    try { editable.dispatchEvent(new Event('compositionstart', { bubbles:true, cancelable:true, composed:true })); } catch(e){}
    try { editable.dispatchEvent(new Event('compositionend', { bubbles:true, cancelable:true, composed:true })); } catch(e){}

    // set selection using the doc's selection API
    try {
      const range = (doc && doc.createRange) ? doc.createRange() : document.createRange();
      range.selectNodeContents(editable);
      range.collapse(false);
      const sel = (doc && doc.getSelection) ? doc.getSelection() : window.getSelection();
      if (sel) {
        try { sel.removeAllRanges(); } catch(e){}
        try { sel.addRange(range); } catch(e){}
      }
    } catch(e){
      console.warn('Selection set failed', e && e.message);
    }

    try { editable.focus && editable.focus(); } catch(e){}
    console.log('Text inserted into chat input. Please press Enter to send.');
    return true;
  } catch (err) {
    console.error('Failed to write into editable node', err && err.message);
    return false;
  }
}

/* ---------- 初回挿入処理 ---------- */
(function main() {
  const container = createUI();

  if (tryInsertIntoChat(container)) return;

  let polls = 0;
  const poller = setInterval(() => {
    polls++;
    if (tryInsertIntoChat(container)) {
      clearInterval(poller);
      return;
    }
    if (polls > 30) {
      clearInterval(poller);
      insertFallback(container);
    }
  }, 500);

  const obs = new MutationObserver((mutations, observer) => {
    if (tryInsertIntoChat(container)) {
      observer.disconnect();
      clearInterval(poller);
    }
  });
  obs.observe(document.body, { childList: true, subtree: true });
})();